from shutil import copyfile
copyfile('Bài Thực Hành 7_Câu 9.py','Bài Thực Hành 7_Câu 8.py')
