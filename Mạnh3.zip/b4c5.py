import array as arr
a=arr.array('i',range(12,38))
print(a) # mang ban dau
b=a[::-1]
print(b) # dao mang
