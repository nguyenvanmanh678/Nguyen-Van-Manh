
from tkinter import *
tk = Tk()
cb=Label(tk, text="Họ và tên: Phan Xuân Hiếu")
cb.grid(column=0,row=1)
cb=Label(tk, text="Lớp: K59TĐH")
cb.grid(column=0,row=2)
cb=Label(tk, text="MSS: 18575202160020")
cb.grid(column=0,row=3)
tk.mainloop()
